ALTER TABLE meetings 
ADD COLUMN google_drive_id VARCHAR(255) NULL,
ADD COLUMN google_drive_link VARCHAR(512) NULL,
ADD COLUMN user_folder_id VARCHAR(255) NULL;
