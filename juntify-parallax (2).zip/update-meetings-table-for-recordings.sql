ALTER TABLE meetings 
ADD COLUMN recordings_folder_id VARCHAR(255) DEFAULT NULL;
